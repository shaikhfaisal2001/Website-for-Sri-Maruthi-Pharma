1.Install Xampp from "https://www.apachefriends.org/download.html"
2.Download the website project from "https://github.com/mendoncagary/Pharmacy-Website" 
3.Unzip it and save it in folder xampp/htdocs/dbms
4.Open Xampp control panel
5.Start Apache and MySql from Xampp Control Panel
6.From browser go to localhost/phpmyadmin and create a database and name it as pharmacy.
7.Click on import.Browse the pharmacy.sql file which is included in "xampp/htdocs/dbms/Database/Pharmacy.sql" and click on go.
This will load the database
8.Now start the website by typing in browser :localhost/dbms/index.php

By Gary Mendonca 
Enjoy!!!!

                    *************************************
